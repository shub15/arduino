# PS5Controller_ESP32
This repository contains code and diagram for PS Controller with esp32
